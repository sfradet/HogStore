<?php
/*
 * Hog Store Website Version 1
 * index.php Version 1
 * Shawn Fradet
 * CST-236
 * 2/28/2021
 * This is the main page for the website.
 */


header("Location: \HogStore\presentation\handlers\productHandler.php");

