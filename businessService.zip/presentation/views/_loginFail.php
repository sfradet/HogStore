<?php
/*
 * Hog Store Website Version 1
 * _loginFail.php Version 1
 * Shawn Fradet
 * CST-236
 * 2/28/2021
 * This page is for displaying failure messages for bad login attempts.
 */
require_once "_header.php";
?>

<div class="container" style="max-width: 600px;">
    <h3 class="text-center my-5">Login failed</h3>
</div>


<?php
require_once  "_footer.php";
?>
